#ifndef EVAL_H
#define EVAL_H
#include "../board/board.h"
#include "../core/types.h"
#include <atomic>
#include <string>
#include <utility>
#include <vector>

namespace Prometheus {

namespace Eval {

// Tunable Parameters
// Material and Phase moved to PST
// extern int Material[PIECE_TYPE_NB][2];
// extern int PhaseWeights[PIECE_TYPE_NB];
extern int SafetyTable[100];
extern int MobilityBonus[PIECE_TYPE_NB];

// Tunable Evaluation Weights
extern int BishopPairMG, BishopPairEG;
extern int OutpostBonus, PermanentOutpostBonus;
extern int HangingPiecePenalty[PIECE_TYPE_NB];
extern int HarassedByPawnPenalty;
extern int OpenFileBonus, SemiOpenFileBonus;
extern int SpaceSquareBonus;

// King Safety Parameters
extern int KingDefenderWeight; // Reduction per defender
extern int CoordinationBonus;  // Bonus per co-attacker
extern int SafeCheckBonus;     // Bonus for safe checks

// Singular Extensions Parameters
extern int SingularMarginMultiplier; // depth * multiplier for beta margin
extern int SingularMinDepth;         // minimum depth to apply SE
extern int DoubleSingularMargin;     // Extra margin for double extension

extern int HistoryLmrDivisor; // Divisor for history reduction
extern int NmpTtMargin;       // Margin for TT-aware NMP pruning

// Pawn Eval Parameters
extern int PawnMajorityBonus;
extern int CandidatePasserBonus;
extern int PawnTensionBonus;    // Maintain tension
extern int PawnBreakBonus;      // Potential pawn breaks
extern int BackwardPawnPenalty; // Backward pawn on semi-open file

// Color Complex & Bishop Interaction
extern int GoodBishopBonus;
extern int BadBishopPenalty;
extern int ColorWeaknessPenalty;

// King Safety - Pawn Storm
extern int PawnStormBonus;

// King Safety - Shield Degradation
extern int Shield1;
extern int Shield2;
extern int MissingShieldPenalty;

// Virtual King Safety
extern int VirtualSafetyWeight;

// LMR (Late Move Reductions) Parameters
extern int LMRBaseReduction;  // Base formula multiplier (×0.01)
extern int LMRDepthDivisor;   // Depth log divisor (×0.01)
extern int LMRHistoryDivisor; // History scaling divisor
extern int LMRPVReduction;    // PV node reduction decrease
extern int LMRImprovingBonus; // Not improving penalty

// Eval Hysteresis (Phase 4)
extern int
    EvalHysteresis; //  Small deterministic variance to smooth transitions

// Internal Iterative Deepening (IID)
extern int IIDMinDepthPV;     // Min depth for IID on PV nodes
extern int IIDMinDepthNonPV;  // Min depth for IID on non-PV nodes
extern int IIDReductionPV;    // Depth reduction for PV IID
extern int IIDReductionNonPV; // Depth reduction for non-PV IID
extern int IIDRetryMinDepth;  // Retry IID if TT move fails low
extern int IIDRetryReduction; // Reduction for IID Retry

// Multi-Cut Pruning
extern int MultiCutThreshold; // Number of beta cutoffs before multi-cut
extern int MultiCutMinDepth;  // Minimum depth for multi-cut pruning
extern int MultiCutReduction; // Depth reduction for multi-cut verification

// Probcut
extern int ProbcutMargin;    // Beta margin for probcut
extern int ProbcutMinDepth;  // Minimum depth for probcut
extern int ProbcutReduction; // Depth reduction for probcut search

// Futility Pruning
extern int FutilityMargin;   // Margin per depth for futility pruning
extern int FutilityMaxDepth; // Maximum depth for futility pruning

// Aspiration Windows
extern int AspirationWindow; // Initial window size
extern int AspirationGrowth; // Window growth per fail
extern int AspirationPanic;  // Panic threshold for wide search

// Extended Futility Pruning
extern int ExtendedFutilityMargin;   // Margin for extended FP
extern int ExtendedFutilityMaxDepth; // Max depth to apply extended FP

// Reverse Futility Pruning
extern int ReverseFutilityMargin;   // Margin for RFP
extern int ReverseFutilityMaxDepth; // Max depth for RFP

// History LMR
// extern int HistoryLmrDivisor; // Defined earlier? No, check line 39. Oh, line
// 39 has it. Wait, I see "extern int HistoryLmrDivisor;" at line 39 in the
// original file view. Let me verify that. Line 39: extern int
// HistoryLmrDivisor; // Divisor for history reduction So I don't need to add it
// here. I just need Extended/Reverse Futility.

// Late Move Pruning
extern int LmpBase;
extern int LmpDepthMultiplier;

// Verified Null Move Pruning Parameters
extern int NmpBaseReduction;
extern int NmpDepthDivisor;
extern int NmpEvalBetaMargin;
extern int NmpVerificationDepth;
extern int NmpVerificationReduction;

// Simple Material Values (centipawns)
constexpr int VALUE_PAWN = 100;
constexpr int VALUE_KNIGHT = 320;
constexpr int VALUE_BISHOP = 330;
constexpr int VALUE_ROOK = 500;
constexpr int VALUE_QUEEN = 900;
constexpr int VALUE_KING = 20000;

// Eval Cache Entry
struct EvalEntry {
  int16_t score;
  uint16_t pad; // Alignment
  std::atomic<uint64_t>
      key; // Key logic: Write score, then Key. Read Key, then Score.
};

class EvalTT {
public:
  EvalTT(size_t size_mb = 4);
  ~EvalTT();

  void resize(size_t size_mb);
  void clear();

  // Probe: If key matches, return true and score.
  bool probe(uint64_t key, int &score) const;

  // Save: Store score for key.
  void save(uint64_t key, int score);

private:
  EvalEntry *table;
  size_t size;
};

extern EvalTT EvalCache;

// Lazy Evaluation Parameters
extern int LazyEvalMargin; // Margin outside window to skip full eval
extern int MaxNonMateEval; // Max eval for non-mate positions

// Tuning / Tracing Support
struct EvalTrace {
  std::vector<std::pair<std::string, double>> terms;

  void add(const std::string &name, double value) {
    terms.push_back({name, value});
  }
};

#define TRACE(trace, name, val)                                                \
  if constexpr (Trace) {                                                       \
    if (trace)                                                                 \
      trace->add(name, (double)(val));                                         \
  }

// Main Evaluation (with lazy eval and depth dampening support)
int evaluate(const Board &board, int alpha = -30000, int beta = 30000,
             int depth = 0);
int evaluate_trace(const Board &board, EvalTrace &trace);

// Helper: Get squares attacked by pawns of a given color
inline Bitboard attacked_by_pawns(const Board &board, Color side) {
  Bitboard pawns = board.pieces(PAWN, side);
  if (side == WHITE) {
    // ((pawns << 9) & 0xFEFEFEFEFEFEFEFEULL) | ((pawns << 7) &
    // 0x7F7F7F7F7F7F7F7FULL)
    return ((pawns << 9) & 0xFEFEFEFEFEFEFEFEULL) |
           ((pawns << 7) & 0x7F7F7F7F7F7F7F7FULL);
  } else {
    // ((pawns >> 9) & 0x7F7F7F7F7F7F7F7FULL) | ((pawns >> 7) &
    // 0xFEFEFEFEFEFEFEFEULL)
    return ((pawns >> 9) & 0x7F7F7F7F7F7F7F7FULL) |
           ((pawns >> 7) & 0xFEFEFEFEFEFEFEFEULL);
  }
}

} // namespace Eval

} // namespace Prometheus

#endif // EVAL_H
